package ch.ilv.m295.demoapp.security;

public class Roles {
    public static final String Admin = "admin";
    public static final String Read = "read";
    public static final String Update = "update";
}
