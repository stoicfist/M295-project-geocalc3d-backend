package ch.ilv.m295.demoapp.hello;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    
    @GetMapping("/hello")
    public String hello(@RequestParam(value="name", defaultValue = "World") String name) {
        return String.format("Hello %s!", name);
    }

    @GetMapping("/api/hello")
    public ResponseEntity<Hello> name(@RequestParam(value="name", defaultValue = "World") String name) {
        Hello hello = new Hello(name);
        return new ResponseEntity<>(hello, HttpStatus.OK);
    }
}