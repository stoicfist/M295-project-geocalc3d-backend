package ch.ilv.m295.demoapp.department;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {

    private final DepartmentRepository repository;

    public DepartmentService(DepartmentRepository repository) {
        this.repository = repository;
    }

    public List<Department> getDepartments() {
        return repository.getDepartments();
    }

    public Department getDepartment(Long id) {
        return repository.getDepartment(id);
    }

}