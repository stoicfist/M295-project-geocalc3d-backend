package ch.ilv.m295.demoapp.department;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class DepartmentRepository {

    public List<Department> getDepartments() {

        Department dep1 = new Department(1L, "Abteilung A");
        Department dep2 = new Department(2L, "Abteilung B");

        return Arrays.asList(dep1,dep2);

    }

    public Department getDepartment(Long id) {

        return new Department(id, "Abteilung A");

    }

}